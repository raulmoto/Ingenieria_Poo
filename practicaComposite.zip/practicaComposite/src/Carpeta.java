import java.util.ArrayList;
import java.util.List;

public class Carpeta implements ElementosDelSistema{
    private String nombre;
    private List<ElementosDelSistema>elementos;
    public Carpeta(String nombre){
        this.nombre = nombre;
        this.elementos = new ArrayList<>();
    }
    public void agregarElemento(ElementosDelSistema e){
        elementos.add(e);

    }
    public void eliminaRELEMENTO(ElementosDelSistema e){
        elementos.remove(e);
    }
    @Override
    public void mostrarEstructura(String prefijo) {
        System.out.println(prefijo + "+ Carpeta: " + nombre);
        for (ElementosDelSistema e: elementos) {
            e.mostrarEstructura(prefijo + " ");
        }
    }

    @Override
    public int obtenerTamanio() {
        int tamanio = 0;
        for (ElementosDelSistema e: elementos) {
            tamanio += e.obtenerTamanio();
        }
        return tamanio;
    }
}
