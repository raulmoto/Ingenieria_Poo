public class Archivo implements ElementosDelSistema{
    private String nombre;
    private int tamanio;
    public Archivo(String nombre,int tamanio){
        this.nombre = nombre;
        this.tamanio = tamanio;
    }
    @Override
    public void mostrarEstructura(String prefijo) {
        System.out.println(prefijo+ "-Nombre: "+nombre+" tamaño: "+tamanio);
    }

    @Override
    public int obtenerTamanio() {
        return tamanio;
    }
}
