// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        //creamos los archivos
        ElementosDelSistema archivo1 = new Archivo("music.Mp3",20);
        ElementosDelSistema archivo2 = new Archivo("music.Mp4",240);
        ElementosDelSistema archivo3 = new Archivo("music.Mp3",70);

        //creamos las carpetas

        ElementosDelSistema carpeta1 = new Carpeta("carpeta A");
        ElementosDelSistema carpeta2 = new Carpeta("carpeta B");
        ElementosDelSistema carpeta3 = new Carpeta("carpeta C");
        //guardamos los archivos en las carpetas B y C
        ((Carpeta)carpeta2).agregarElemento(archivo1);
        ((Carpeta)carpeta2).agregarElemento(archivo2);
        ((Carpeta)carpeta3).agregarElemento(archivo3);
        //agregamos a la carpeta principal las otras dos
        ((Carpeta)carpeta1).agregarElemento(carpeta2);
        ((Carpeta)carpeta1).agregarElemento(carpeta3);
        //mostramos estructura
        ((Carpeta)carpeta1).mostrarEstructura(" ");
        System.out.println("\nTamaño total de la carpeta principal: " + ((Carpeta)carpeta1).obtenerTamanio() + " KB");
    }
}