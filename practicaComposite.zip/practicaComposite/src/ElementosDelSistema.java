public interface ElementosDelSistema {
    void mostrarEstructura(String prefijo);
    int  obtenerTamanio();
}
