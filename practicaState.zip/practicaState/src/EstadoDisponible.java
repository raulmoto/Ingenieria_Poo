public class EstadoDisponible implements EstadoCoche {


    @Override
    public void manejarEsatdo(Coche coche) {
        System.out.println("El coche está disponible para la venta o alquiler.");
    }
}
