public class EstadoVendido implements EstadoCoche{
    @Override
    public void manejarEsatdo(Coche coche) {
        System.out.println("El coche ha sido vendido. No está disponible.");
    }
}
