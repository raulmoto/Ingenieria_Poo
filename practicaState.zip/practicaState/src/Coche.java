public class Coche {
    private String matricula;
    private EstadoCoche estado;
    public Coche(String matricula) {
        this.matricula = matricula;
        this.estado = new EstadoDisponible(); // Estado inicial
    }

    public void setEstado(EstadoCoche nuevoEstado) {
        this.estado = nuevoEstado;
    }

    public void manejarEstado() {
        estado.manejarEsatdo(this);
    }
}
