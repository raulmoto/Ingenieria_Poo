public interface EstadoCoche {
    void manejarEsatdo(Coche coche);
}
