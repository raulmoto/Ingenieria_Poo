public class EstadoEnReparacion implements EstadoCoche {
    @Override
    public void manejarEsatdo(Coche coche) {
        System.out.println("El coche está en reparación. No se puede alquilar ni vender.");
    }
}
