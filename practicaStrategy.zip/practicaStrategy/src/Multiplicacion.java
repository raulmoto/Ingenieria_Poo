public class Multiplicacion implements Operacion {
    private double a,b;
    public Multiplicacion(double a, double b){
        this.a = a;
        this.b = b;
    }
    @Override
    public void calcular() {
        double res = this.a * this.b;
        System.out.println(" el producto es :"+res);
    }
}
