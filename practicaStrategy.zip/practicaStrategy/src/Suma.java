import javax.rmi.ssl.SslRMIClientSocketFactory;

public class Suma implements Operacion {
    private double a,b;
    public Suma(double a, double b){
        this.a = a;
        this.b = b;
    }

    @Override
    public void calcular() {
        double res = this.a + this.b;
        System.out.println(" la suma es :"+res);
    }
}
