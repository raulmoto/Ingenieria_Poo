public class Calculadora {

    private Operacion operacion;
    public void cambiarEstrategia(Operacion operacion){
        this.operacion = operacion;
    }
    public void ejecutar(){
        if(operacion == null){
            System.out.println("profavor, elija una estrategia");
            return;
        }
        operacion.calcular();
    }

}
