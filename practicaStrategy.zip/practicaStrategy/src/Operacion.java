public interface Operacion {
    void calcular();
}
