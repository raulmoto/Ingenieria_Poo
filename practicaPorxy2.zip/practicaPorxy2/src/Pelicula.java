public class Pelicula implements I_Stream{
    private String nombre;
    private String tipo;
    public Pelicula (String nombre, String tipo){
        this.nombre = nombre;
        this.tipo = tipo;

    }
    @Override
    public void verPelicula() {
        System.out.println("Está viendo la película: "+nombre+" de acceso ["+tipo+"]");
    }

    @Override
    public String getTipo() {
        return this.tipo;
    }
}
