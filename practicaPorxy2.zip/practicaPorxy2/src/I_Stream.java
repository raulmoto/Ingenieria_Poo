public interface I_Stream {
    void verPelicula();
    String getTipo();
}
