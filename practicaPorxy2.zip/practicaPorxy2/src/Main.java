import java.util.ArrayList;
import java.util.List;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        //creamso las peliculas
        I_Stream pelicula1 = new Pelicula("Vandame","public");
        I_Stream pelicula2 = new Pelicula("karate-kit2","premium");
        I_Stream pelicula3 = new Pelicula("hulk4","vip");
        List<I_Stream> multimedias = new ArrayList<>();
        multimedias.add(pelicula1);
        multimedias.add(pelicula2);
        multimedias.add(pelicula3);
        //ahora simulamos que el usario quiere ver una pelicula
        I_Stream proxy = new Proxy_Stream("premium",multimedias);
        proxy.verPelicula();
    }
}