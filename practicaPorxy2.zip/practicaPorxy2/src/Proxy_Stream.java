import java.util.List;

public class Proxy_Stream implements I_Stream{
    private List<I_Stream> multimedias;
    private String tipoUsuario;
    public Proxy_Stream(String tipo, List<I_Stream>multimedias){
        this.tipoUsuario = tipo;
        this.multimedias = multimedias;
    }
    @Override
    public void verPelicula() {
        for (I_Stream pelicula:multimedias) {
            if(tienePermiso(pelicula.getTipo())){
                pelicula.verPelicula();
            }
        }
    }

    @Override
    public String getTipo() {
        return this.tipoUsuario;
    }

   public boolean tienePermiso(String tipoPelicula){
        if(tipoPelicula.equals("public")){
            return true;// totdo pueden verlo
        }else if(tipoPelicula.equals("premium")){
            //si la pelicula es premium, a menos que el usario sea premium o vip no lo vera
            return tipoUsuario.equals("premium") || tipoUsuario.equals("vip");
        }else if (tipoPelicula.equals("vip")){
            return tipoUsuario.equals("vip");
        }
        return  false;
   }
}
