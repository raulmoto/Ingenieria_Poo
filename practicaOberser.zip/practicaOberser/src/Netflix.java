import java.util.ArrayList;

public class Netflix {
    //Esta clase será la clase sujeto
    private String estado = "";//define el estado del objeto
    private ArrayList<Observador> observadores = new ArrayList<>();
    public Netflix(){
    }
    /**
     * Cuando el usaurio se suscribe, el usario es un observador y por lo tanto guardamo el observador en la
     * lista de observadores.
     * */
    public void suscribirse(Observador observador){
        observadores.add(observador);
    }
    public void darsedeBaja(Observador observador){
        observadores.remove(observador);

    }
    /**
     * Cuando se produce un cambio en el estado de un sujeto o notificador, este se actualiza y
     * se llama al método notificarAtodos que lo que hace es recorres la lista de estados y ejecutar el metodo actualizar
     * que está en la interfaz.
     * */
    public void cambiarEstado(String sms){
        this.estado = sms;
        notificarAtodos();
    }
    /**
     * Se recorre la lista de observadores y se llama al metodo actualizar que esta sobreescrito con un print de mensaje en la clase cliente
     * */
    public void notificarAtodos(){
        for (Observador o: observadores) {
                o.actualizar(estado);
        }
    }
}