public interface Observador {
    void actualizar(String estado);
}
