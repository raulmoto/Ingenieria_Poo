// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        //primero definimos el notificador sujeto
        Netflix netflix = new Netflix();
        //ahora el cliente
        Observador observador1 = new Cliente("Luis");
        Observador observador2 = new Cliente("Pedro");
        //agregamos observador
        netflix.suscribirse(observador1);
        netflix.suscribirse(observador2);
        netflix.cambiarEstado("Nuevas peliculas de estreno");
    }
}